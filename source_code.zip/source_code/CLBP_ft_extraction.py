import cv2, os,numpy as np
from scipy.ndimage.filters import convolve


def CLBP(gray_image):
    def get_pixel(img, center, x, y):
        new_value = 0
        try:
            if img[x][y] >= center:
                new_value = 1
        except:
            pass
        return new_value

    def clbp_sign_vec(img, x, y):
        '''
         64 | 128 |   1
        ----------------
         32 |   0 |   2
        ----------------
         16 |   8 |   4
        '''
        center = img[x][y]
        val_ar = []
        val_ar.append(get_pixel(img, center, x - 1, y + 1))  # top_right
        val_ar.append(get_pixel(img, center, x, y + 1))  # right
        val_ar.append(get_pixel(img, center, x + 1, y + 1))  # bottom_right
        val_ar.append(get_pixel(img, center, x + 1, y))  # bottom
        val_ar.append(get_pixel(img, center, x + 1, y - 1))  # bottom_left
        val_ar.append(get_pixel(img, center, x, y - 1))  # left
        val_ar.append(get_pixel(img, center, x - 1, y - 1))  # top_left
        val_ar.append(get_pixel(img, center, x - 1, y))  # top

        power_val = [1, 2, 4, 8, 16, 32, 64, 128]
        val = 0
        # print(val_ar)
        for i in range(len(val_ar)):
            val += val_ar[i] * power_val[i]
        return val

    imgLBP = np.zeros_like(gray_image)
    neighboor = 3
    for ih in range(0, gray_image.shape[0] - neighboor):
        for iw in range(0, gray_image.shape[1] - neighboor):
            ### Step 1: 3 by 3 pixel
            img = gray_image[ih:ih + neighboor, iw:iw + neighboor]
            center = img[1, 1]
            img01 = (img >= center) * 1.0
            img01_vector = img01.T.flatten()
            # it is ok to order counterclock manner
            # img01_vector = img01.flatten()
            ### Step 2: **Binary operation**:
            img01_vector = np.delete(img01_vector, 4)
            ### Step 3: Decimal: Convert the binary operated values to a digit.
            where_img01_vector = np.where(img01_vector)[0]
            if len(where_img01_vector) >= 1:
                num = np.sum(2 ** where_img01_vector)
            else:
                num = 0
            imgLBP[ih + 1, iw + 1] = num

    # To extract LBP features

    height, width = gray_image.shape
    img_clbp = np.zeros((height, width, 3), np.uint8)
    for i in range(0, height):
        for j in range(0, width):
            img_clbp[i, j] = clbp_sign_vec(gray_image, i, j)

    return img_clbp