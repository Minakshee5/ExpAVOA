import numpy as np
from sklearn.model_selection import train_test_split
import Dcnn
import global_model

def run(time_stamp):
    ACC, TNR, TPR, LOSS, MSE, RMSE = [], [], [], [], [], []
    for i in range(time_stamp):
        tr_per = 0.9
        ## to load data ##
        data = np.load('FeatAllFin_data1.npy')
        lab = np.load('lab1.npy')

        ## to load data 2
        data2 = np.load('featAllFinData2.npy')
        lab2 = np.load('lab2.npy')
        ## to split the data into 3 for 3 local models
        data_1_1, data_1_2, data_1_3 = np.split(data, 3)
        lab_1_1, lab_1_2, lab_1_3 = np.split(lab, 3)
        data_2_1, data_2_2, data_2_3 = np.split(data2,3)
        lab_2_1, lab_2_2, lab_2_3 = np.split(lab2, 3)

        #-------- weights from local models
        #####---------------------------------------------------
        x_train1_1,x_test1_1,y_train1_1,y_test1_1 =train_test_split(data_1_1, lab_1_1,train_size=tr_per,random_state=123)
        # getting weight from the local model
        wt1 = Dcnn.dcnn_weights(x_train1_1, y_train1_1, x_test1_1, y_test1_1)
        k1 = len(wt1)
        wt1_fin = np.mean(wt1[k1-1])
        ####-------------------------------------------------
        x_train2_1,x_test2_1,y_train2_1,y_test2_1 =train_test_split(data_2_1,lab_2_1,train_size=tr_per,random_state=123)
        # getting weight from the local model
        wt2 = Dcnn.dcnn_weights(x_train2_1, y_train2_1, x_test2_1, y_test2_1)
        k2 = len(wt2)
        wt2_fin = np.mean(wt2[k2-1])
        ####---------------------------------------------
        x_train1_2,x_test1_2,y_train1_2,y_test1_2 =train_test_split(data_1_2,lab_1_2,train_size=tr_per,random_state=123)
        # getting weight from the local model
        wt3 = Dcnn.dcnn_classification(x_train1_2, y_train1_2, x_test1_2, y_test1_2)
        k3 = len(wt3)
        wt3_fin = np.mean(wt3[k3-1])
        ####-------------------------------------------------------------
        x_train2_2,x_test2_2,y_train2_2,y_test2_2 =train_test_split(data_2_2,lab_2_2,train_size=tr_per,random_state=123)
        # getting weight from the local model
        wt4 = Dcnn.dcnn_weights(x_train2_2, y_train2_2, x_test2_2, y_test2_2)
        k4 = len(wt4)
        wt4_fin = np.mean(wt4[k4-1])
        ####-------------------------------------------------------------
        x_train1_3,x_test1_3,y_train1_3,y_test1_3 =train_test_split(data_1_3,lab_1_3,train_size=tr_per,random_state=123)
        # getting weight from the local model
        wt5 = Dcnn.dcnn_weights(x_train1_3, y_train1_3, x_test1_3, y_test1_3)
        k5 = len(wt5)
        wt5_fin = np.mean(wt5[k5-1])
        ####-------------------------------------------------------------------
        x_train2_3,x_test2_3,y_train2_3,y_test2_3 =train_test_split(data_2_3,lab_2_3,train_size=tr_per,random_state=123)
        # getting weight from the local model
        wt6 = Dcnn.dcnn_weights(x_train2_3,y_train2_3, x_test2_3, y_test2_3)
        k6 = len(wt6)
        wt6_fin = np.mean(wt6[k6-1])
        wt_all = np.array([wt1_fin,wt2_fin,wt3_fin,wt4_fin,wt5_fin,wt6_fin],dtype=float)
        wt = abs(np.mean(wt_all))

        acc, tnr, tpr, loss, mse, rmse = global_model.global_model_run(wt)
        ###  appending values in list
        ACC.append(acc)
        TNR.append(tnr)
        TPR.append(tpr)
        LOSS.append(loss)
        MSE.append(mse)
        RMSE.append(rmse)
    return np.mean(ACC), np.mean(TNR), np.mean(TPR), np.mean(LOSS), np.mean(MSE), np.mean(RMSE)

time_stamp = 20 #---- can vary 40,60,80,100
# ---- call function
ACC, TNR, TPR, LOSS, MSE, RMSE = run(time_stamp)
# ----- print values
print(ACC, TNR, TPR, LOSS, MSE, RMSE )