from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten, BatchNormalization, Activation
from keras.layers.convolutional import Conv1D, MaxPooling1D
# from CNN import read
import expAPO
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import logging
logging.getLogger('tensorflow').disabled = True
import warnings
warnings.filterwarnings("ignore")
import numpy as np
from tensorflow.keras.optimizers import Adam as opt

def dcnn_weights(train_data, train_label, test_data, test_label):
    # normalize the inputs from more value to between 0 and 1 by dividing by max number
    train_data = train_data.astype('float32')
    test_data = test_data.astype('float32')
    train_data = train_data / np.max(train_data)
    test_data = test_data / np.max(test_data)
    # CNN for 1D vectors
    num_clas = len(np.unique(train_label))
    from numpy import newaxis
    from keras.utils import to_categorical
    train_x = train_data[:, :, newaxis]
    train_y = to_categorical(train_label)
    test_x = test_data[:,:, newaxis]
    test_y = to_categorical(test_label)
    # evaluate model
    verbose, epochs, batch_size = 0, 5, 32
    n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
    model = Sequential()
    model.add(Conv1D(filters=32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
    model.add(Conv1D(filters=64, kernel_size=3, activation='relu'))
    model.add(Dropout(0.5))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))

    model.add(Dense(num_clas, activation='softmax'))

    model.compile(loss = "categorical_crossentropy", optimizer = opt(lr=expAPO.opt()[0]), metrics=['accuracy'])
    # model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    print(model.summary())
    # fit network
    model.fit(train_x, train_y, epochs=epochs, batch_size=batch_size,verbose=0)
    wt = model.get_weights()
    return wt


def dcnn_classification(train_data, train_label, test_data, test_label,wt):
    # normalize the inputs from more value to between 0 and 1 by dividing by max number
    target = np.concatenate((train_label,test_label),axis=0)
    train_data = train_data.astype('float32')
    test_data = test_data.astype('float32')
    train_data = train_data / np.max(train_data)
    test_data = test_data / np.max(test_data)
    # CNN for 1D vectors
    n_clas = len(np.unique(train_label))
    from numpy import newaxis
    from keras.utils import to_categorical
    train_x = train_data[:, :, newaxis]
    train_y = to_categorical(train_label)
    test_x = test_data[:,:, newaxis]
    test_y = to_categorical(test_label)
    # evaluate model
    verbose, epochs, batch_size = 0, 5, 32
    n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
    model = Sequential()
    model.add(Conv1D(filters=32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
    model.add(Conv1D(filters=64, kernel_size=3, activation='relu'))
    model.add(Dropout(0.5))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))

    model.add(Dense(n_clas, activation='softmax'))
    k = model.get_weights()
    model.set_weights(k+wt)

    model.compile(loss = "categorical_crossentropy", optimizer = opt(lr = expAPO.opt()[0]), metrics=['accuracy'])
    # model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    print(model.summary())
    # fit network
    model.fit(train_x, train_y, epochs=epochs, batch_size=batch_size)
    predict = model.predict(test_data)
    pred1 = np.argmax(predict,axis=1)
    pred_fin = np.concatenate((train_label,pred1),axis=0)
    return target, pred_fin





