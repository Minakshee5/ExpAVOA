import cv2
import os
path1 ='dataset'

listing = os.listdir(path1)

for file in listing:
    filename = os.path.join(path1, file)

    img = cv2.imread(filename)
    nlm_filtr = cv2.fastNlMeansDenoisingColored(img,None,10,10,7,21)


    out_filename1 = os.path.join('filtered_image', file)
    cv2.imwrite(out_filename1, nlm_filtr)

