import numpy as np
from sklearn.model_selection import train_test_split
import Dcnn
import overlap_coefficient
from sklearn.metrics import mean_squared_error
import math
def global_model_run(wt):
    tr_per = 0.9
    ## to load image data ##
    data = np.load('FeatAllFin_data1.npy')
    lab = np.load('lab1.npy')

    ## to load data 2
    data2 = np.load('featAllFinData2.npy')
    lab2 = np.load('lab2.npy')

    #----------------  for image data

    x_train1_1,x_test1_1,y_train1_1,y_test1_1 = train_test_split(data,lab,train_size=tr_per,random_state=123)

    target1,pred1 = Dcnn.dcnn_classification(x_train1_1, y_train1_1, x_test1_1, y_test1_1,wt)

    #------------ training for signal data
    x_train2_1,x_test2_1,y_train2_1,y_test2_1 =train_test_split(data2,lab2,train_size=tr_per,random_state=123)

    target2, pred2 = Dcnn.dcnn_classification(x_train2_1, y_train2_1, x_test2_1, y_test2_1, wt)

    coff = overlap_coefficient.overlap(pred1,pred2)
    if coff == 1:
        pred_fin = pred1
        target_fin = target1
    else:
        pred_fin = pred2
        target_fin = target2

    uni = np.unique(target_fin)
    tp, tn, fn, fp = 0, 0, 0, 0  # unique label
    for i1 in range(len(uni)):
        c = uni[i1]
        for i in range(len(target_fin)):

            if (target_fin[i] == c and pred_fin[i] == c):
                tp = tp + 1
            if (target_fin[i] != c and pred_fin[i] != c):
                tn = tn + 1
            if (target_fin[i] == c and pred_fin[i] != c):
                fn = fn + 1
            if (target_fin[i] != c and pred_fin[i] == c):
                fp = fp + 1
    tp = tn / len(uni)
    fn = fn / len(uni)

    acc = (tp + tn) / (tp + fn + tn + fp)
    tpr = tp / (tp + fn)
    tnr = tn / (tn + fp)
    loss = 1 - acc

    mse = mean_squared_error(target_fin, pred_fin)
    rmse = math.sqrt(mse)

    return acc, tnr, tpr, loss, mse, rmse


