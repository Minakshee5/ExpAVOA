import os
import numpy as np
from scipy.io import wavfile
from scipy.ndimage import gaussian_filter
from python_speech_features import mfcc
import librosa
##### Parent Dir #####

dataDir = 'dataset2'

subDirs = os.listdir(dataDir)
FeatAllFin = []
for j in range(len(subDirs)):


      dir = subDirs[j]
      dict ={0:1,1:1,2:1,3:0,4:1,5:1,6:0,7:1,8:0,9:1,10:1,11:0,12:0,13:1,14:0,15:0,16:1,17:1,18:0,19:1,20:1}
      # list out keys and values separately
      key_list = list(dict.keys())
      val_list = list(dict.values())
      position = key_list.index(j)
      lab = [val_list[position]]
      lab = np.array(lab)
      dataPath = os.path.join(dataDir,dir)
      fileName = os.listdir(dataPath)
      filePath = os.path.join(dataPath,fileName[0])

      samplerate, data = wavfile.read(filePath)

      ##### Preprocessing #####
      dataPreprocess = gaussian_filter(data, sigma=1)

      ##### Feature Extraction #####
      #### MKMFCC ####

      ## spliting signal ##
      time = 40
      samples = 40/1000*samplerate
      lenSamples = int(len(data)/samples)
      lenInit = 0
      sampleLen = lenSamples
      sig =[]
      for i in range(int(samples)):
           sig1 = data[lenInit:sampleLen]
           sig.append(sig1)
           lenInit=lenInit+lenSamples
           sampleLen = sampleLen+lenSamples
      arr = np.array(sig)
      arrinit = arr[0]
      arrinit =arrinit.reshape(1,arrinit.shape[0])
      arrAll = arrinit
      for i1 in range(arr.shape[0]-1):
           print(i1)
           arr1 = arr[i1+1]
           arr1 = arr1.reshape(1,arr1.shape[0])
           arrAll = np.concatenate((arrAll,arr1),axis=0)
      print(filePath)
      featAll_sig = []
      for i2 in range(arrAll.shape[0]):
           features_mfcc = mfcc(arrAll[i2,:], samplerate)
           MKMfcc = np.mean(features_mfcc,axis=0)
           MKMfcc = MKMfcc.reshape(1,MKMfcc.shape[0])

           ##### Spectural flux #####
           onset_env = librosa.onset.onset_strength(y=np.float32(arrAll[i2,:]), sr=samplerate,
           aggregate=np.median,
           fmax=16000, n_mels=256)
           onset_env = onset_env.reshape(1,onset_env.shape[0])
           onset_envFin = onset_env[:,0:13]

           #### Spectural centroid ####
           Spe_centroid = librosa.feature.spectral_centroid(y=np.float32(arrAll[i2,:]), sr=samplerate)
           Spe_centroid_fin = Spe_centroid[:,0:13]

           #### Zero crossing rate ####
           ftZeroCross = librosa.feature.zero_crossing_rate(np.float32(arrAll[i2,:]))
           ftZeroCrossFin = ftZeroCross[:,0:13]

           #### chroma feat ####
           chroma = librosa.feature.chroma_stft(y=np.float32(arrAll[i2,:]), sr=samplerate)
           chromaFt = np.mean(chroma,axis=0)
           chromaFt =chromaFt.reshape(1,chromaFt.shape[0])
           chromaFin = chromaFt[:,0:13]

           #### Spectral bandwidth ####
           Spe_bandwidth = librosa.feature.spectral_bandwidth(y=np.float32(arrAll[i2,:]), sr=samplerate)
           Spe_bandwidth_fin = Spe_bandwidth[:,0:13]

           featAll = np.concatenate((MKMfcc,onset_envFin,Spe_centroid_fin,ftZeroCrossFin,chromaFin,Spe_bandwidth_fin),axis= 1)
           an_array = np.insert(featAll, 52, lab, axis=1)
           featAll_sig.append(an_array)
      featAll_sig = np.array(featAll_sig)
      featAll_sig= featAll_sig.reshape(featAll_sig.shape[0],featAll_sig.shape[2])

      FeatAllFin.append(featAll_sig)
FinalFeatArr = FeatAllFin[0]
for k in range(len(FeatAllFin)-1):
    arr = FeatAllFin[k+1]
    FinalFeatArr = np.concatenate((FinalFeatArr, arr), axis=0)

np.save('featAllFinData2.npy',FinalFeatArr)
print('Feature has been extracted and saved........! ')
