import cv2, os,numpy as np
from scipy.ndimage.filters import convolve

def LDTP_Ext(img):
    #  Apply the compass Frei–Chen masks
    # input image 'img' is grayscale image in range 0-1
    msk1 = np.array([[1 / (2 * np.sqrt(2)), np.sqrt(2) / (2 * np.sqrt(2)), 1 / (2 * np.sqrt(2))], [0, 0, 0],
                     [-1 / (2 * np.sqrt(2)), -np.sqrt(2) / (2 * np.sqrt(2)), -1 / (2 * np.sqrt(2))]])  # east
    msk2 = np.array([[1 / (2 * np.sqrt(2)), 0, -1 / (2 * np.sqrt(2))],
                     [np.sqrt(2) / (2 * np.sqrt(2)), 0, -np.sqrt(2) / (2 * np.sqrt(2))],
                     [1 / (2 * np.sqrt(2)), 0, -1 / (2 * np.sqrt(2))]])  # north-east
    msk3 = np.array(
        [[0, -1 / (2 * np.sqrt(2)), np.sqrt(2) / (2 * np.sqrt(2))], [1 / (2 * np.sqrt(2)), 0, -1 / (2 * np.sqrt(2))],
         [-np.sqrt(2) / (2 * np.sqrt(2)), 1 / (2 * np.sqrt(2)), 0]])  # north
    msk4 = np.array(
        [[np.sqrt(2) / (2 * np.sqrt(2)), -1 / (2 * np.sqrt(2)), 0], [-1 / (2 * np.sqrt(2)), 0, 1 / (2 * np.sqrt(2))],
         [0, 1 / (2 * np.sqrt(2)), -np.sqrt(2) / (2 * np.sqrt(2))]])  # north-west
    msk5 = np.array([[0, 1 / 2, 0], [-1 / 2, 0, -1 / 2], [0, 1 / 2, 0]])  # west
    msk6 = np.array([[-1 / 2, 0, 1 / 2], [0, 0, 0], [1 / 2, 0, -1 / 2]])  # south-west
    msk7 = np.array([[1 / 6, -2 / 6, 1 / 6], [-2 / 6, 4 / 6, -2 / 6], [1 / 6, -2 / 6, 1 / 6]])  # south
    msk8 = np.array([[-2 / 6, 1 / 6, -2 / 6], [1 / 6, 4 / 6, 1 / 6], [-2 / 6, 1 / 6, -2 / 6]])  # south-east
    msk9 = np.array([[1 / 4, -2 / 4, 1 / 4], [2 / 4, -4 / 4, 2 / 4], [1 / 4, -2 / 4, 1 / 4]])  # south-east
    res1 = convolve(img, msk1)
    res2 = convolve(img, msk2)
    res3 = convolve(img, msk3)
    res4 = convolve(img, msk4)
    res5 = convolve(img, msk5)
    res6 = convolve(img, msk6)
    res7 = convolve(img, msk7)
    res8 = convolve(img, msk8)
    res9 = convolve(img, msk9)
    sk = np.stack((res5, res6, res7, res8, res1, res2, res3, res4, res9), 2)
    skb = sk > 0
    bin = [1, 2, 4, 8, 16, 32, 64, 128]
    skb = skb.astype(np.float)
    out = np.sum(skb, 2)
    image_ldp = cv2.normalize(src=out, dst=None, alpha=255, beta=0, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    image_height = image_ldp.shape[0]
    image_width = image_ldp.shape[1]

    def heaviside(x, y):

        if x > 3 and y > 3:
            return 2
        elif x < -3 and y < -3:
            return 1
        else:
            return 0

    def get_features(image, image_height, image_width):

        zeroHorizontal = np.zeros(image_width + 2).reshape(1, image_width + 2)
        zeroVertical = np.zeros(image_height).reshape(image_height, 1)

        features = []

        image = np.concatenate((image, zeroVertical), axis=1)
        image = np.concatenate((zeroVertical, image), axis=1)
        image = np.concatenate((zeroHorizontal, image), axis=0)
        image = np.concatenate((image, zeroHorizontal), axis=0)

        pattern_image = np.zeros((image_height + 1, image_width + 1))

        for x in range(1, image_height + 1):
            for y in range(1, image_width + 1):
                s1 = heaviside(image[x - 1, y - 1] - image[x, y], image[x, y] - image[x + 1, y + 1])
                s3 = heaviside(image[x - 1, y + 1] - image[x, y], image[x, y] - image[x + 1, y - 1]) * 3

                s = s1 + s3

                pattern_image[x, y] = s

        pattern_image = pattern_image[1:(image_height + 1), 1:(image_width + 1)].astype(int)
        histogram = np.histogram(pattern_image, bins=np.arange(17))[0]
        histogram = histogram.reshape(1, -1)

        features.append(histogram)
        features = np.concatenate(features, axis=0)

        return features, pattern_image

    out, out_2 = get_features(image_ldp, image_height, image_width)
    ldtp = cv2.normalize(src=out_2, dst=None, alpha=255, beta=0, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    return ldtp