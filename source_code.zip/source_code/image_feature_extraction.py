import cv2
import os
import numpy as np
import LDTP
import LGBP
import CLBP_ft_extraction
import phog
path1 ='filtered_image'

listing = os.listdir(path1)
feat =  []
for file in listing:
    filename = os.path.join(path1, file)

    img = cv2.imread(filename)

    ## to extract volumetric feat
    imgVolFt = img
    imgVolFt[imgVolFt > 0] = 255
    cnts, hier = cv2.findContours(np.uint8(imgVolFt), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    size_elements = 0
    thickness = 0
    for cnt in cnts:
        cv2.drawContours(np.uint8(imgVolFt.copy()), cnt, -1, (0, 0, 255), 3)
        size_elements += cv2.contourArea(cnt)
        (x, y), radius = cv2.minEnclosingCircle(cnt)
        thick = 2 * radius
        thickness += thick
    volFeat = [size_elements, thickness]
    #### To Extract Texture Feature ####
    ####  LGBP Feat ####
    lgbp_img = LGBP.LGBP(img)
    norm_image = cv2.normalize(lgbp_img, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
    maxVal = np.max(norm_image)
    minVal = np.min(norm_image)
    lgbpFT = cv2.calcHist([norm_image], [int(minVal)], None, [50], [0, int(maxVal)])
    lgbpFTFin = lgbpFT.reshape(lgbpFT.shape[1], lgbpFT.shape[0])

    #### LDTP Feat ####
    LDTP_img = LDTP.LDTP_Ext(img)
    norm_ldtp_img = cv2.normalize(LDTP_img, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
    maxVal = np.max(norm_ldtp_img)
    minVal = np.min(norm_ldtp_img)
    ldtpFT = cv2.calcHist([norm_ldtp_img], [int(minVal)], None, [50], [0, int(maxVal)])
    ldtpFTFin = ldtpFT.reshape(ldtpFT.shape[1], ldtpFT.shape[0])

    #### CLBP Feat ####
    clbp = CLBP_ft_extraction.CLBP(img)
    clbp_gray = cv2.cvtColor(clbp, cv2.COLOR_BGR2GRAY)
    norm_clbp_img = cv2.normalize(clbp_gray, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX,
                                  dtype=cv2.CV_32F)
    maxVal = np.max(norm_clbp_img)
    minVal = np.min(norm_clbp_img)
    clbpFT = cv2.calcHist([norm_clbp_img], [int(minVal)], None, [50], [0, int(maxVal)])
    clbpFTFin = clbpFT.reshape(clbpFT.shape[1], clbpFT.shape[0])

    #### PHOG Feat ####
    bin = 2
    angle = 360
    Level = 3
    roi = [1, img.shape[0], 1, img.shape[1]]
    p = phog.anna_phog(img, bin, angle, Level, roi)
    p = p.reshape(1, p.shape[0])
    #### texture feat concatenate ####
    textur_ft = np.concatenate((lgbpFTFin, ldtpFTFin, clbpFTFin, p), axis=1)
    #### volumetric feat ####
    vol_ft = np.array(volFeat)
    vol_ft = vol_ft.reshape(1, vol_ft.shape[0])
    #### to concatenate texture and vol feature ####
    feat_all = np.concatenate((vol_ft, textur_ft), axis=1)

    #### to append all feature in list ####
    feat.append(feat_all)
feat = np.array(feat)
np.save('FeatAllFin_data1.npy',feat)