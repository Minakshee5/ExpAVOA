def overlap(A, B):
    set_A = set(A)
    set_B = set(B)

    intersection = set_A.intersection(set_B)
    intersection_size = len(intersection)

    min_size = min(len(set_A), len(set_B))

    if min_size == 0:
        return 0  # To handle the case when one of the arrays is empty

    return intersection_size / min_size